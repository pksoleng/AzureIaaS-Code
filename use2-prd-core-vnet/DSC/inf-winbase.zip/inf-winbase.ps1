Configuration Main
{
  
  param (
    [String]$DomainName,
    [System.Management.Automation.PSCredential]$AdminCreds,
    [String]$SiteName,
    [Int]$RetryCount=20,
    [Int]$RetryIntervalSec=30
  )
  
  [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential `
  ("$(Get-NetbiosName $domainName)\$($Admincreds.UserName)", $Admincreds.Password)

  Import-DscResource -ModuleName PSDesiredStateConfiguration, xComputerManagement, PowerShellModule
 
  node $Allnodes.NodeName
  {
    LocalConfigurationManager
    {
      ConfigurationMode = �ApplyOnly�
      RebootNodeIfNeeded = $true
    }
    WindowsFeature TelnetClient
    {
	    Name = "Telnet-Client"
	    Ensure = "Present"
    }
    xComputer DomainJoin
    {
      Name = $env:COMPUTERNAME
      DomainName = $DomainName
      Credential = $DomainCreds
    }
  }
}

function get-netbiosName ($domainFQDN) {
  $domainFQDN.Split('.')[-2]
}

$ConfigData = @{
  AllNodes = @(
    @{
      NodeName = "localhost";
      #PSDscAllowPlainTextPassword = $true;
    }
  );
}