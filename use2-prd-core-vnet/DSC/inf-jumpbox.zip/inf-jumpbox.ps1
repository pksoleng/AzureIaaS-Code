Configuration Main
{
  param (
    [String]$DomainName,
    [System.Management.Automation.PSCredential]$AdminCreds,
    [String]$SiteName,
    [Int]$RetryCount=20,
    [Int]$RetryIntervalSec=30
  )

  $artifactsDir = "C:\Image Artifacts"
  $artifactsShare = "\\azcorusvsa1.file.core.usgovcloudapi.net\jumpbox-artifacts"
  $artifactsShareUser = "AZURE\azcorusvsa1"
  $artifactsSharePwd =  ConvertTo-SecureString "JQl6Y4HBS9cqOZASHlnfznJoi6dR/jMzUervnsqir0cuuERtDJ5Hsn7Jx68hcxjhkj+ZsKv/hZhncuB40emjLQ==" `
  -AsPlainText -Force 

  [System.Management.Automation.PSCredential]$SACreds = New-Object System.Management.Automation.PSCredential `
  ($artifactsShareUser, $artifactsSharePwd)
  
  [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential `
  ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

  Import-DscResource -ModuleName PSDesiredStateConfiguration, xComputerManagement, PowerShellModule
 
  node $Allnodes.NodeName
  {
    LocalConfigurationManager
    {
      ConfigurationMode = �ApplyOnly�
      RebootNodeIfNeeded = $true
    }
    WindowsFeature GPMC
    {
	    Name = "GPMC"
	    Ensure = "Present"
    }
    WindowsFeature RSATADTools
    {
	    Name = "RSAT-AD-Tools"
	    Ensure = "Present"
    }
    WindowsFeature UpdateServicesRSAT
    {
	    Name = "UpdateServices-RSAT"
	    Ensure = "Present"
    }
    WindowsFeature TelnetClient
    {
	    Name = "Telnet-Client"
	    Ensure = "Present"
    }
    Script CreateArtifactsDir
    {
      TestScript = {
        Test-Path $using:artifactsDir
      }
      SetScript ={
        New-Item -ItemType Directory -Path "$using:artifactsDir" -Force
      }
      GetScript = { @{Result = "CreateArtifactsDir"} }
    }
    Script CopyArtifacts
    {
      TestScript = {
        return $false
      }
      SetScript ={
	      net use * /delete /y
        New-PSDrive -Name artifacts -PSProvider FileSystem -Root $using:artifactsShare -Credential $using:SACreds `
        -ErrorAction Stop -WarningAction Stop

        rm "$($using:artifactsDir)\*" -Recurse -Force
        cp artifacts:\* "$using:artifactsDir" -Recurse -Force
      }
      GetScript = { @{Result = "CopyArtifacts"} }
      DependsOn = "[Script]CreateArtifactsDir"
    }
    PSModuleResource PowerShellGet
    {
      Ensure = "Present"
      Module_Name = "PowerShellGet"
    }
    PSModuleResource AzureRm
    {
      Ensure = "Present"
      Module_Name = "AzureRM"
    }
    PSModuleResource Azure
    {
      Ensure = "Present"
      Module_Name = "Azure"
    }
    xComputer DomainJoin
    {
      Name = $env:COMPUTERNAME
      DomainName = $DomainName
      Credential = $DomainCreds
      DependsOn = "[Script]CopyArtifacts"
    }
  }
}

$ConfigData = @{
  AllNodes = @(
    @{
      NodeName = "localhost";
      #PSDscAllowPlainTextPassword = $true;
    }
  );
}