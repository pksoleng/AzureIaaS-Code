﻿configuration DeployADDC 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [String]$SiteName,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory,xDisk, xNetworking, cDisk, PSDesiredStateConfiguration
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    $Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)

    Node localhost
    {
		Script AddADDSFeature {
			SetScript = {
			Add-WindowsFeature "AD-Domain-Services" -ErrorAction SilentlyContinue
			Add-WindowsFeature RSAT-ADDS -IncludeAllSubFeature -ErrorAction SilentlyContinue
			}
			GetScript =  { @{} }
			TestScript = { $false }
		}
	
		WindowsFeature DNS 
		{ 
			Ensure = "Present" 
			Name = "DNS"		
		}

		Script DnsServerDiag
		{
      		SetScript =  { 
				Set-DnsServerDiagnostics -All $true
				Write-Verbose -Verbose "Enabling DNS client diagnostics" 
			}
			GetScript =  { @{} }
			TestScript = { $false }
			DependsOn = "[WindowsFeature]DNS"
		}

		WindowsFeature DnsTools
		{
			Ensure = "Present"
			Name = "RSAT-DNS-Server"
		}

		xWaitforDisk Disk2
		{
				DiskNumber = 2
				RetryIntervalSec =$RetryIntervalSec
				RetryCount = $RetryCount
		}

		cDiskNoRestart ADDataDisk
		{
			DiskNumber = 2
			DriveLetter = "F"
		}

		WindowsFeature ADDSInstall 
		{ 
			Ensure = "Present" 
			Name = "AD-Domain-Services"
			DependsOn="[cDiskNoRestart]ADDataDisk", "[Script]AddADDSFeature"
		}
		
		xADDomainController DeployDS 
		{
			DomainName = $DomainName
			DomainAdministratorCredential = $DomainCreds
			SafemodeAdministratorPassword = $DomainCreds
			DatabasePath = "F:\NTDS"
			LogPath = "F:\NTDS"
			SysvolPath = "F:\SYSVOL"
			DependsOn = "[WindowsFeature]ADDSInstall"
		}
		
		Script CreateADSite
		{
			SetScript = {
				if ($Using:SiteName) {
                    Write-Verbose -Verbose "Attempting to create specified site $siteName"					
                    
                    $siteName = $Using:SiteName
					$Env:ADPS_LoadDefaultDrive = 0
					$nodeInfo = Get-WmiObject Win32_ComputerSystem
					$nodeFQDN = “{0}.{1}” -f $nodeInfo.Name, $nodeInfo.Domain

					Import-Module ActiveDirectory -ErrorAction Stop
					New-PSDrive -PSProvider ActiveDirectory -Server $nodeFQDN -Root "" -Name AD -FormatType Canonical -ErrorAction Stop | Out-Null
					CD AD:

					$configNCDN = (Get-ADRootDSE).ConfigurationNamingContext
					$siteContainerDN = (“CN=Sites,” + $configNCDN)
					$sites = Get-ADObject -SearchBase $siteContainerDN –filter "objectClass -eq 'site'”

					if ($sites.Name -contains $siteName) {
						Write-Verbose "Site $siteName already exists in this domain"
					} else {
						try {
							New-ADReplicationSite -Name $SiteName -Confirm:$false -Passthru -ErrorAction Stop -ErrorVariable errMsgSite
						} catch {
							Write-Verbose "Unable to create site $siteName"
							Throw $errMsgSite.Exception.Message
						}
						Write-Verbose "Site $siteName was successfully created"
						Remove-PSDrive AD -Force
					}
				}
			}
			GetScript =  { @{} }
			TestScript = { $false }
			DependsOn = "[xADDomainController]DeployDS"
			Credential = $DomainCreds
		}
		
		Script MoveDSToSite
		{
			SetScript = {
				if ($Using:SiteName) {
					$siteName = $Using:SiteName
					$Env:ADPS_LoadDefaultDrive = 0
					$nodeInfo = Get-WmiObject Win32_ComputerSystem
					$nodeFQDN = “{0}.{1}” -f $nodeInfo.Name, $nodeInfo.Domain
					Write-Verbose -Verbose "Attempting to to move $nodeFQDN to $siteName"

					Import-Module ActiveDirectory -ErrorAction Stop
					New-PSDrive -PSProvider ActiveDirectory -Server $nodeFQDN -Root "" -Name AD -FormatType Canonical -ErrorAction Stop | Out-Null
					CD AD:	

					$nodeInfo = Get-WmiObject Win32_ComputerSystem
					$nodeFQDN = “{0}.{1}” -f $nodeInfo.Name, $nodeInfo.Domain
					$nodeDSObj = Get-ADDomainController -Identity $nodeFQDN
					$nodeCurrSite = $nodeDSObj.Site

					if ($siteName -eq $nodeCurrSite) {
						Write-Verbose "DS $nodeFQDN is already located in site $siteName"
					} else {
						try { 
							$nodeDSObj | Move-ADDirectoryServer -Site $sitename -ErrorAction Stop
						} catch {
							$errMsg = $Error[0].Exception.Message
						}

						if ($errMsg -eq $null){
							Write-Verbose "DS $nodeFQDN was successfully moved to $siteName"
						} else {
							Throw "Uanble to move DS $nodeFQDNd to $siteName`n$errMsg"
						}
					}
					Remove-PSDrive AD -Force
				}
			}
			GetScript =  { @{} }
			TestScript = { $false }
			DependsOn = "[Script]CreateADSite"
			Credential = $DomainCreds
		}
		
		xDnsServerAddress DnsServerAddress 
		{ 
			Address        = '127.0.0.1' 
			InterfaceAlias = $InterfaceAlias
			AddressFamily  = 'IPv4'
			DependsOn = "[xADDomainController]DeployDS"
		}
        
		Script SetAzureForwarder
		{
			SetScript = {
			    Write-Verbose -Verbose "Attempting to set DNS forwarder to the Azure Forwarder Service IP"
			    $nodeInfo = Get-WmiObject Win32_ComputerSystem
			    $nodeFQDN = “{0}.{1}” -f $nodeInfo.Name, $nodeInfo.Domain
                
				try {
				    Import-Module DNSServer -ErrorAction Stop
			        Get-DnsServerForwarder | Remove-DnsServerForwarder -Force -Confirm:$false
                    Add-DnsServerForwarder -IPAddress 168.63.129.16
				} catch {
					Write-Verbose "Unable to set DNS forwarder on $nodeFQDN"
					Throw $Error[0].Exception.Message
				}
				Write-Verbose -Verbose "Set DNS forwarder to Azure Forwarder Service IP on $nodeFQDN"
			}
			GetScript =  { @{} }
			TestScript = { $false }
			DependsOn = "[xDnsServerAddress]DnsServerAddress"
			Credential = $DomainCreds
		}

        LocalConfigurationManager 
		{
			ConfigurationMode = 'ApplyOnly'
			RebootNodeIfNeeded = $true
		}
	}
} 